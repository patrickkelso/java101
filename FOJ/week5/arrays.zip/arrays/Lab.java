public class Lab
{
    private static int[] DAYS_IN_MONTH = { 31, 28, 31, 30 }; // add all 12 months to this array!
    public static int getDayOfYear(int day, int month)
    {
        return 0;
    }
}
